module.exports = {
    mongoURI: 'mongodb+srv://3ctjgrupo6:Fiaptech2024@cluster0.pwplit6.mongodb.net/FiapNews?retryWrites=true&w=majority&appName=Cluster0'
};
